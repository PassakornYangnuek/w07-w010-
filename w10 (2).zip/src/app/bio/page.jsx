import Menu from "@/components/menu";
import Image from "next/image";


export default function Bio() {
    return (
        <div className="w-full p-2 flex justify-center text-white bg-[#222222]">
            <h1>Copyright by Passakorn Yangnuek</h1>
        </div>
    );
}
