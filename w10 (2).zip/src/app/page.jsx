import Image from "next/image";
import Menu from "@/components/menu";
import Banner from "@/components/banner";
import Content from "@/components/content";
import MyCard from "@/components/mycard";
import Footer from "@/components/footer";
export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center bg-[url('https://game.capcom.com/manual/MHW/img/common/bg.jpg')] bg-cover">
      <div className="w-full">
        <Menu />
      </div>
      <div className="w-full">
        <Banner />
      </div>
      <div className="w">
        <Content />
      </div>
      <div className="flex gap-3">
        <MyCard imgUrl={"https://game.capcom.com/manual/MHW/img/page/81_2_1.jpg?t=202007090000"} cardHeader={"Great Sword"} />
        <MyCard imgUrl={"https://game.capcom.com/manual/MHW/img/page/81_3_1.jpg?t=202007090000"} cardHeader={"Long Sword"} />
        <MyCard imgUrl={"https://game.capcom.com/manual/MHW/img/page/81_4_1.jpg?t=202007090000"} cardHeader={"Sword & Shield"} />
        <MyCard imgUrl={"https://game.capcom.com/manual/MHW/img/page/81_5_1.jpg?t=202007090000"} cardHeader={"Dual Blade"} />
      </div>

      <Footer />

    </main>
  );
}
