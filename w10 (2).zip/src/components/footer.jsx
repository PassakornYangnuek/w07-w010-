export default function Footer() {
    return (
        <div className="w-full p-2 flex justify-center text-white bg-[#222222] mt-2">
            <h1>Copyright by Passakorn Yangnuek</h1>
        </div>
    );
}
