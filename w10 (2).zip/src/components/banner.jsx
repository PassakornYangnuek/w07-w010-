export default function Banner() {
    return (
        <div>
            <img src="https://hb.imgix.net/5cd392b5c84d7c39383ec65ea14b711031728dba.png?auto=compress,format&bg=E4E7ED&fm=jpg&max-h=750&q=80&s=dc6fdcf468da63946cb5076abfa58268" alt="banner" />
        </div>
    );


}