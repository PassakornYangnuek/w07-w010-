export default function Content() {
    return (
        <div><h1 className="text-center text-3xl" > NEWS</h1>
            <div>
                <h1>Web Sercies Technologoy</h1>
            </div>
            <div>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Fugit error voluptas autem quos nobis quibusdam voluptates incidunt doloribus accusamus ipsa! Culpa obcaecati fugit eum consectetur, ipsa sed nisi voluptas magnam.</p>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Fugit error voluptas autem quos nobis quibusdam voluptates incidunt doloribus accusamus ipsa! Culpa obcaecati fugit eum consectetur, ipsa sed nisi voluptas magnam.</p>
            </div>
            <div>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Fugit error voluptas autem quos nobis quibusdam voluptates incidunt doloribus accusamus ipsa! Culpa obcaecati fugit eum consectetur, ipsa sed nisi voluptas magnam.</p>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Fugit error voluptas autem quos nobis quibusdam voluptates incidunt doloribus accusamus ipsa! Culpa obcaecati fugit eum consectetur, ipsa sed nisi voluptas magnam.</p>
            </div>
        </div>
    );
}