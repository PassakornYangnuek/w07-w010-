import Link from "next/link";

export default function Menu() {
    return (
        <nav className="bg-[#222222] text-[#b4b2b0] p-5">
            <div className="flex items-center gap-5">
                <Link href={`/`}
                    className="hover:text-white"
                >
                    HOME
                </Link>
                <Link href={`/bio`}
                    className="hover:text-white"
                >
                    BIO
                </Link>
                <Link href={`/vaccine_record`}
                    className="hover:text-white"
                >
                    Vaccine Record
                </Link>
            </div>
        </nav>
    );
}