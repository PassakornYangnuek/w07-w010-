<?php

use Illuminate\Http\Request;
use App\Http\Controllers\AuthController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\VaccineApiController;
use App\Http\Controllers\StudentApiController;
use App\Http\Controllers\FacultyApiController;
use App\Http\Controllers\ProgramApiController;
use App\Http\Controllers\VaccineRecordApiController;
use Spatie\FlareClient\Api;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/
// Public routes
Route::post('/register', [AuthController::class, 'register']);
Route::post('/login', [AuthController::class, 'login']);
Route::get('/vaccine', [VaccineApiController::class, 'index']);
Route::get('/vaccine/{id}', [VaccineApiController::class, 'show']);
Route::get('/vaccine/search/{name}', [VaccineApiController::class,'search']);

Route::get('/student', [StudentApiController::class, 'index']);
Route::get('/student/{id}', [StudentApiController::class, 'show']);
Route::get('/student/search/{name}', [StudentApiController::class,'search']);


Route::get('/faculty', [FacultyApiController::class, 'index']);
Route::get('/faculty/{id}', [FacultyApiController::class, 'show']);
Route::get('/faculty/search/{name}', [FacultyApiController::class,'search']);


Route::get('/program', [ProgramApiController::class, 'index']);
Route::get('/program/{id}', [ProgramApiController::class, 'show']);
Route::get('/program/search/{name}', [ProgramApiController::class,'search']);


Route::get('/vaccinerecord', [VaccineRecordApiController::class, 'index']);
Route::get('/vaccinerecord/{id}', [VaccineRecordApiController::class, 'show']);
Route::get('/vaccinerecord/search/{name}', [VaccineRecordApiController::class,'search']);

// Protected routes
Route::group(['middleware' => ['auth:sanctum']], function () {
Route::post('/vaccine', [VaccineApiController::class, 'store']);
Route::put('/vaccine/{id}', [VaccineApiController::class, 'update']);
Route::delete('/vaccine/{id}', [VaccineApiController::class, 'destroy']);

Route::post('/student', [StudentApiController::class, 'store']);
Route::put('/student/{id}', [StudentApiController::class, 'update']);
Route::delete('/student/{id}', [StudentApiController::class, 'destroy']);

Route::post('/faculty', [FacultyApiController::class, 'store']);
Route::put('/faculty/{id}', [FacultyApiController::class, 'update']);
Route::delete('/faculty/{id}', [FacultyApiController::class, 'destroy']);

Route::post('/program', [ProgramApiController::class, 'store']);
Route::put('/program/{id}', [ProgramApiController::class, 'update']);
Route::delete('/program/{id}', [ProgramApiController::class, 'destroy']);

Route::post('/vaccinerecord', [VaccineRecordApiController::class, 'store']);
Route::put('/vaccinerecord/{id}', [VaccineRecordApiController::class, 'update']);
Route::delete('/vaccinerecord/{id}', [VaccineRecordApiController::class, 'destroy']);

Route::post('/logout', [AuthController::class, 'logout']);

});
// Route::middleware('auth:api')->get('/user', function (Request $request) {
//     return $request->user();
// });
// API routes